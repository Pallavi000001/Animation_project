import 'package:flutter/material.dart';
import 'package:animated_splash_screen/animated_splash_screen.dart';
import 'package:lottie/lottie.dart';
import 'onboard_screen.dart';

class SplashScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return AnimatedSplashScreen(
      splashIconSize: 300,
      splash: SizedBox(
        width: 300,  // Adjust the width
        height: 300,  // Adjust the height
        child: Lottie.asset('assets/namaste.json'),
      ),
     // splash: Lottie.asset('assets/namaste.json'),
      nextScreen: OnboardScreen(),
      splashTransition: SplashTransition.fadeTransition,
      backgroundColor: Colors.yellow,
    );
  }
}
