import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

class NotificationScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.yellow.shade200,
      appBar:AppBar(

        title: Text('Notification ',style: TextStyle(color: Colors.white,fontSize: 17)),
        flexibleSpace: Stack(
          fit: StackFit.expand,
          children: [
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.red, Colors.orange],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
            ),
            Center(
              child: Container(
                height: MediaQuery.of(context).size.height / 4,
                width: MediaQuery.of(context).size.height / 14.8,
                child: Lottie.asset(
                  'assets/namaste.json',
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ],
        ),
      ),


      body: Center(
        child: Column(
          children: [
            SizedBox(height:MediaQuery.of(context).size.height/5),
            Lottie.asset(
              'assets/god5.json',
              fit: BoxFit.cover,
            ),
            Text('Notification Screen',style: TextStyle(fontSize: 24, color: Colors.red),),
          ],
        ),
      ),
    );
  }
}
