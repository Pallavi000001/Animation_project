import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'package:audioplayers/audioplayers.dart';

class PujaScreen extends StatefulWidget {
  @override
  _PujaScreenState createState() => _PujaScreenState();
}

class _PujaScreenState extends State<PujaScreen> {
  final List<String> _animations = [
    'assets/god5.json',
    'assets/god4.json',
    'assets/god6.json',
  ];
  int _currentAnimationIndex = 0;
  bool _showFlowers = false;
  bool _rotateThali = false;
  AudioPlayer _audioPlayer = AudioPlayer();

  void _playShankh() async {
    await _audioPlayer.play(AssetSource('shankh_sound.mp3'));
  }

  void _changeAnimation() {
    setState(() {
      _currentAnimationIndex = (_currentAnimationIndex + 1) % _animations.length;
    });
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.yellow.shade200,
      appBar: AppBar(
        title: Text('Puja App', style: TextStyle(color: Colors.white,fontSize: 17)),
        flexibleSpace: Stack(
          fit: StackFit.expand,
          children: [
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.red, Colors.orange],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
            ),
            Center(
              child: Container(
                height: MediaQuery.of(context).size.height / 4,
                width: MediaQuery.of(context).size.height / 14.8,
                child: Lottie.asset(
                  'assets/namaste.json',
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ],
        ),
      ),
      body: Stack(
        children: [
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  height: 200,
                  child: Lottie.asset(_animations[_currentAnimationIndex]),
                ),
                SizedBox(height: 100),
                Wrap(
                  spacing: 10,
                  children: [
                    ElevatedButton(
                      onPressed: () {
                        setState(() {
                          _showFlowers = !_showFlowers;
                        });
                      },
                      child: Text('Flowers'),
                    ),
                    ElevatedButton(
                      onPressed: () {
                        setState(() {
                          _rotateThali = !_rotateThali;
                        });
                      },
                      child: Text('Arti Thali'),
                    ),
                    ElevatedButton(
                      onPressed: _playShankh,
                      child: Text('Blow Shankh'),
                    ),
                    ElevatedButton(
                      onPressed: _changeAnimation,
                      child: Text('Change Animation'),
                    ),
                  ],
                ),
              ],
            ),
          ),
          if (_showFlowers)
            Stack(
              children: [
                Positioned(
                  top: 100, // Adjust this value to change the vertical position
                  left: 0,
                  right:0,
                  child: Center(
                    child: Lottie.asset(
                      'assets/q.json',
                      repeat: true,
                      height: 300
                    ),
                  ),
                ),
              ],
            ),

          if (_rotateThali)
            Center(
              child: Lottie.asset('assets/thali.json', repeat: true, height: 200),
            ),
        ],
      ),
    );
  }
}
