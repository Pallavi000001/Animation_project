import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'profile_screen.dart';
import 'change_password_screen.dart';
import 'splash_screen.dart';


class MainScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
    return Scaffold(
      backgroundColor: Colors.yellow.shade200,
      drawer: AppDrawer(),
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 60.0,
            floating: false,
            pinned: true,
            // leading: IconButton(
            //           icon: Icon(Icons.menu, size: 36),
            //           onPressed: (){
            //             _scaffoldKey.currentState?.openDrawer();
            //             Scaffold.of(context).openDrawer();
            //
            //
            //           }  // And this!
            //         ),
            flexibleSpace: FlexibleSpaceBar(
              centerTitle: false,
             // leading:Icon(Icons.menu,colors:Colors.red)
              title: Text('', style: TextStyle(color: Colors.white, fontSize: 16)),
              background: Stack(
                fit: StackFit.expand,
                children: [
                  Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [Colors.red, Colors.orange],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                    ),
                  ),
                  SizedBox(
                    child: Center(
                      child: Lottie.asset(
                        'assets/namaste.json',
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          SliverFillRemaining(
            hasScrollBody: false,
            child: Center(
              child: Column(
                children: [
                  SizedBox(height:MediaQuery.of(context).size.height/5),
                  Lottie.asset(
                    'assets/god5.json',
                    fit: BoxFit.cover,
                  ),
                  Center(
                    child: Text(
                      'Welcome to Puja App',
                      style: TextStyle(fontSize: 24, color: Colors.red),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class AppDrawer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: Column(
        children: [
          Container(
            height: 200,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.red, Colors.orange],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Lottie.asset(
                    'assets/god5.json',
                    height: 100,
                    width: 120,
                  ),
                  Text(
                    'User Name',
                    style: TextStyle(color: Colors.yellow),
                  ),
                  Text(
                    'user@gmail.com',
                    style: TextStyle(color: Colors.white),
                  ),
                ],
              ),
            ),
          ),
          Expanded(
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                AnimatedListTile(
                  icon: Icons.person,
                  title: 'Profile',
                  color: Colors.red,
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => ProfileScreen()),
                    );
                  },
                ),
                AnimatedListTile(
                  icon: Icons.lock,
                  title: 'Change Password',
                  color: Colors.red,
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => ChangePasswordScreen()),
                    );
                  },
                ),
                AnimatedListTile(
                  icon: Icons.logout,
                  title: 'Logout',
                  color: Colors.red,
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => SplashScreen()),
                    );
                    // Implement logout functionality here
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class AnimatedListTile extends StatefulWidget {
  final IconData icon;
  final String title;
  final Color color;
  final VoidCallback onTap;

  const AnimatedListTile({
    Key? key,
    required this.icon,
    required this.title,
    required this.color,
    required this.onTap,
  }) : super(key: key);

  @override
  _AnimatedListTileState createState() => _AnimatedListTileState();
}

class _AnimatedListTileState extends State<AnimatedListTile>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    _animation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: _animation,
      child: ListTile(
        leading: Icon(widget.icon, color: widget.color),
        title: Text(
          widget.title,
          style: TextStyle(
            color: widget.color,
            fontSize: 18, // Adjust font size as needed
            fontWeight: FontWeight.bold,
          ),
        ),
        onTap: widget.onTap,
      ),
    );
  }
}
